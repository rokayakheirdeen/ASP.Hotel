﻿namespace ASP.HOTELS.Models
{
    public class Index
    {
        public int HotelId { get; internal set; }
    }
}